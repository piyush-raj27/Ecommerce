package com.demo.ecommerce.model;

public enum Role {
    CUSTOMER,
    ADMIN
}
