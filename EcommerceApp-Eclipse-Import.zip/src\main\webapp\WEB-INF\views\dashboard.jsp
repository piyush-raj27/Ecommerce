<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/styles.css">
</head>
<body>
<main class="dashboard">
    <header>
        <div>
            <h1>Welcome, ${sessionScope.loggedInUser.fullName}</h1>
            <p>Role: ${sessionScope.loggedInUser.roleName}</p>
        </div>
        <form method="post" action="${pageContext.request.contextPath}/logout">
            <button type="submit" class="secondary">Logout</button>
        </form>
    </header>

    <section>
        <c:choose>
            <c:when test="${sessionScope.loggedInUser.roleName == 'ADMIN'}">
                <h2>Admin Area</h2>
                <p>You can manage products, categories, inventory, and order status from here.</p>
            </c:when>
            <c:otherwise>
                <h2>Customer Area</h2>
                <p>You can browse products, manage cart items, and place orders from here.</p>
            </c:otherwise>
        </c:choose>
    </section>
</main>
</body>
</html>
