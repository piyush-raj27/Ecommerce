package com.demo.ecommerce.service;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

public class EmailService {
    private final Properties properties = new Properties();

    public EmailService() {
        try (InputStream inputStream = getClass().getClassLoader().getResourceAsStream("mail.properties")) {
            if (inputStream == null) {
                throw new IllegalStateException("mail.properties not found");
            }
            properties.load(inputStream);
        } catch (IOException ex) {
            throw new IllegalStateException("Unable to load mail properties", ex);
        }
    }

    public void sendOtp(String to, String code, String purpose) {
        String username = properties.getProperty("mail.username");
        String password = properties.getProperty("mail.password");

        Properties smtp = new Properties();
        smtp.put("mail.smtp.host", properties.getProperty("mail.smtp.host"));
        smtp.put("mail.smtp.port", properties.getProperty("mail.smtp.port"));
        smtp.put("mail.smtp.auth", properties.getProperty("mail.smtp.auth"));
        smtp.put("mail.smtp.starttls.enable", properties.getProperty("mail.smtp.starttls.enable"));

        Session session = Session.getInstance(smtp, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                return new PasswordAuthentication(username, password);
            }
        });

        try {
            Message message = new MimeMessage(session);
            message.setFrom(new InternetAddress(properties.getProperty("mail.from")));
            message.setRecipients(Message.RecipientType.TO, InternetAddress.parse(to));
            message.setSubject("Your Ecommerce Demo OTP");
            message.setText("Your OTP for " + purpose + " is " + code + ". It expires in 10 minutes.");
            Transport.send(message);
        } catch (MessagingException ex) {
            throw new IllegalStateException("Unable to send OTP email", ex);
        }
    }
}
