package com.demo.ecommerce.service;

import com.demo.ecommerce.dao.OtpTokenDao;
import com.demo.ecommerce.dao.UserDao;
import com.demo.ecommerce.model.OtpPurpose;
import com.demo.ecommerce.model.OtpToken;
import com.demo.ecommerce.model.Role;
import com.demo.ecommerce.model.User;
import com.demo.ecommerce.util.PasswordUtil;

import java.security.SecureRandom;
import java.time.LocalDateTime;

public class AuthService {
    private static final int OTP_MINUTES = 10;
    private final UserDao userDao = new UserDao();
    private final OtpTokenDao otpTokenDao = new OtpTokenDao();
    private final EmailService emailService = new EmailService();
    private final SecureRandom random = new SecureRandom();

    public User signup(String fullName, String email, String password, Role role) {
        if (userDao.findByEmail(email) != null) {
            throw new IllegalArgumentException("Email is already registered.");
        }
        User user = new User(fullName.trim(), email.trim().toLowerCase(), PasswordUtil.hash(password), role);
        userDao.save(user);
        createAndSendOtp(user, OtpPurpose.SIGNUP);
        return user;
    }

    public User beginLogin(String email, String password) {
        User user = userDao.findByEmail(email);
        if (user == null || !PasswordUtil.matches(password, user.getPasswordHash())) {
            throw new IllegalArgumentException("Invalid email or password.");
        }
        createAndSendOtp(user, OtpPurpose.LOGIN);
        return user;
    }

    public User verifyOtp(Long userId, String code, OtpPurpose purpose) {
        OtpToken token = otpTokenDao.findActiveToken(userId, code, purpose);
        if (token == null || token.getExpiresAt().isBefore(LocalDateTime.now())) {
            throw new IllegalArgumentException("Invalid or expired OTP.");
        }
        otpTokenDao.markUsed(token);
        User user = userDao.findById(userId);
        if (purpose == OtpPurpose.SIGNUP && !user.isEmailVerified()) {
            user.setEmailVerified(true);
            userDao.update(user);
        }
        return user;
    }

    public User resendOtp(Long userId, OtpPurpose purpose) {
        User user = userDao.findById(userId);
        if (user == null) {
            throw new IllegalArgumentException("User not found.");
        }
        createAndSendOtp(user, purpose);
        return user;
    }

    private void createAndSendOtp(User user, OtpPurpose purpose) {
        String code = String.format("%06d", random.nextInt(1000000));
        OtpToken token = new OtpToken(user, code, purpose, LocalDateTime.now().plusMinutes(OTP_MINUTES));
        otpTokenDao.save(token);
        emailService.sendOtp(user.getEmail(), code, purpose.name().toLowerCase());
    }
}
