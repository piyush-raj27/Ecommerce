<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Signup</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/styles.css">
</head>
<body>
<main class="auth-shell">
    <section class="auth-panel">
        <h1>Signup</h1>
        <c:if test="${not empty error}">
            <div class="alert error">${error}</div>
        </c:if>
        <form method="post" action="${pageContext.request.contextPath}/signup">
            <label>Full name</label>
            <input type="text" name="fullName" required>

            <label>Email</label>
            <input type="email" name="email" required>

            <label>Password</label>
            <input type="password" name="password" minlength="6" required>

            <label>Role</label>
            <select name="role" required>
                <option value="CUSTOMER">Customer</option>
                <option value="ADMIN">Admin</option>
            </select>

            <button type="submit">Create account</button>
        </form>
        <p>Already registered? <a href="${pageContext.request.contextPath}/login">Login</a></p>
    </section>
</main>
</body>
</html>
