package com.demo.ecommerce.web;

import com.demo.ecommerce.model.OtpPurpose;
import com.demo.ecommerce.service.AuthService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/resend-otp")
public class ResendOtpServlet extends HttpServlet {
    private final AuthService authService = new AuthService();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Long userId = (Long) request.getSession().getAttribute("pendingUserId");
        String purposeName = (String) request.getSession().getAttribute("otpPurpose");
        if (userId == null || purposeName == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        try {
            authService.resendOtp(userId, OtpPurpose.valueOf(purposeName));
            request.setAttribute("message", "A new OTP has been sent.");
        } catch (RuntimeException ex) {
            request.setAttribute("error", ex.getMessage());
        }
        request.getRequestDispatcher("/WEB-INF/views/verify-otp.jsp").forward(request, response);
    }
}
