package com.demo.ecommerce.model;

public enum OtpPurpose {
    SIGNUP,
    LOGIN
}
