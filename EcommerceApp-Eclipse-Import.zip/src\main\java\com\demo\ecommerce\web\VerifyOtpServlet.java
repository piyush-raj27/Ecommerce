package com.demo.ecommerce.web;

import com.demo.ecommerce.model.OtpPurpose;
import com.demo.ecommerce.model.User;
import com.demo.ecommerce.service.AuthService;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebServlet("/verify-otp")
public class VerifyOtpServlet extends HttpServlet {
    private final AuthService authService = new AuthService();

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        if (request.getSession().getAttribute("pendingUserId") == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }
        request.getRequestDispatcher("/WEB-INF/views/verify-otp.jsp").forward(request, response);
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        Long userId = (Long) request.getSession().getAttribute("pendingUserId");
        String purposeName = (String) request.getSession().getAttribute("otpPurpose");
        if (userId == null || purposeName == null) {
            response.sendRedirect(request.getContextPath() + "/login");
            return;
        }

        try {
            User user = authService.verifyOtp(userId, request.getParameter("otp"), OtpPurpose.valueOf(purposeName));
            request.getSession().removeAttribute("pendingUserId");
            request.getSession().removeAttribute("otpPurpose");
            request.getSession().setAttribute("loggedInUser", user);
            response.sendRedirect(request.getContextPath() + "/dashboard");
        } catch (RuntimeException ex) {
            request.setAttribute("error", ex.getMessage());
            request.getRequestDispatcher("/WEB-INF/views/verify-otp.jsp").forward(request, response);
        }
    }
}
