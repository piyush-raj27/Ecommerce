package com.demo.ecommerce.dao;

import com.demo.ecommerce.model.OtpPurpose;
import com.demo.ecommerce.model.OtpToken;
import com.demo.ecommerce.util.HibernateUtil;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

public class OtpTokenDao {
    public void save(OtpToken otpToken) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            session.save(otpToken);
            transaction.commit();
        } catch (RuntimeException ex) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw ex;
        }
    }

    public OtpToken findActiveToken(Long userId, String code, OtpPurpose purpose) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            Query<OtpToken> query = session.createQuery(
                    "select t from OtpToken t join fetch t.user " +
                            "where t.user.id = :userId and t.code = :code and t.purpose = :purpose and t.used = false " +
                            "order by t.expiresAt desc",
                    OtpToken.class);
            query.setParameter("userId", userId);
            query.setParameter("code", code);
            query.setParameter("purpose", purpose);
            query.setMaxResults(1);
            return query.uniqueResult();
        }
    }

    public void markUsed(OtpToken token) {
        Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            transaction = session.beginTransaction();
            OtpToken managed = session.get(OtpToken.class, token.getId());
            managed.setUsed(true);
            session.update(managed);
            transaction.commit();
        } catch (RuntimeException ex) {
            if (transaction != null) {
                transaction.rollback();
            }
            throw ex;
        }
    }
}
