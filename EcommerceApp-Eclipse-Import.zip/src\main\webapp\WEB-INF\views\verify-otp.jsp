<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Verify OTP</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/styles.css">
</head>
<body>
<main class="auth-shell">
    <section class="auth-panel">
        <h1>Verify OTP</h1>
        <c:if test="${not empty error}">
            <div class="alert error">${error}</div>
        </c:if>
        <c:if test="${not empty message}">
            <div class="alert success">${message}</div>
        </c:if>
        <form method="post" action="${pageContext.request.contextPath}/verify-otp">
            <label>Six digit OTP</label>
            <input type="text" name="otp" maxlength="6" pattern="[0-9]{6}" required>
            <button type="submit">Verify</button>
        </form>
        <form method="post" action="${pageContext.request.contextPath}/resend-otp" class="inline-form">
            <button type="submit" class="secondary">Resend OTP</button>
        </form>
    </section>
</main>
</body>
</html>
