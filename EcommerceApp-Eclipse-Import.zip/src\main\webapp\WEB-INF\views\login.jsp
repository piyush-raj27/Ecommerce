<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <title>Login</title>
    <link rel="stylesheet" href="${pageContext.request.contextPath}/assets/styles.css">
</head>
<body>
<main class="auth-shell">
    <section class="auth-panel">
        <h1>Login</h1>
        <c:if test="${not empty error}">
            <div class="alert error">${error}</div>
        </c:if>
        <form method="post" action="${pageContext.request.contextPath}/login">
            <label>Email</label>
            <input type="email" name="email" required>

            <label>Password</label>
            <input type="password" name="password" required>

            <button type="submit">Send OTP</button>
        </form>
        <p>New user? <a href="${pageContext.request.contextPath}/signup">Create an account</a></p>
    </section>
</main>
</body>
</html>
